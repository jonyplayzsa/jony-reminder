# Jony Reminder Pro PWA Prep V4

Single-file app. Upload index.html to GitHub Pages.
